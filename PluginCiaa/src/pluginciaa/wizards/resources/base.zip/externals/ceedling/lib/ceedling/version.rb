# @private
module Ceedling
  module Version
    # @private
    GEM = "0.13.0"

    # @private
    CEEDLING = GEM
    # @private
    CEXCEPTION = "1.2.17"
    # @private
    CMOCK = "2.0.215"
    # @private
    UNITY = "2.1.0"
  end
end
